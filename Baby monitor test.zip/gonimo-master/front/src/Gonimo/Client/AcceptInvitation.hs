{-# LANGUAGE RecursiveDo #-}
module Gonimo.Client.AcceptInvitation ( module UI
                                      ) where

import Gonimo.Client.AcceptInvitation.UI as UI
