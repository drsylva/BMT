{-# LANGUAGE RecursiveDo #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TemplateHaskell #-}
module Gonimo.Client.Parent
  ( module UI
  -- , module Parent
  ) where

-- import Gonimo.Client.Parent.Internal as Parent
import Gonimo.Client.Parent.UI as UI
