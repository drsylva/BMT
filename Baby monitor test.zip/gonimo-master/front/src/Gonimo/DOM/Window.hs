module Gonimo.DOM.Window ( module Internal
                         ) where

import Gonimo.DOM.Window.Internal as Internal
