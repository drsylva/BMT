Gonimo-Back
===========

[![Build Status](https://travis-ci.org/gonimo/gonimo-back.svg?branch=master)](https://travis-ci.org/gonimo/gonimo-back)
Good Night Monitor - Backend part

gonimo
------

[gonimo][1] is a free open-source baby monitoring application,
developed by Robert Klotzner, funded by [netidee.at][2]


[1]: https://gonimo.com/
[2]: https://www.netidee.at/

