/*
  Environment for gonimo-front.

  Here things like backend url can be set.
 */

window.gonimoEnv = {
    // Whether to use https/wss or not:
    secure : false,
    gonimoBackServer : "localhost:8081",
    gonimoTurnConnection : "turn:gonimo.com:3478",
    gonimoTurnUser : "gonimo",
    gonimoTurnPassword : "Aeloh5chai2eil1",
    gonimoTurnCredentialType : "password"
};
